package com.zensar.service;

import com.zensar.entities.Customer;

public class CustomerServiceImpl implements CustomerService{

	public Customer findProductById(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
	}

	public void updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
	}

	public void removeCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
	}

}
