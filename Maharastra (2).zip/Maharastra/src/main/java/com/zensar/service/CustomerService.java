package com.zensar.service;

import com.zensar.entities.Customer;

public interface CustomerService {

	Customer findProductById(int productId);
    void addCustomer(Customer customer);
    void updateCustomer(Customer customer);
    void removeCustomer(Customer customer);
}
